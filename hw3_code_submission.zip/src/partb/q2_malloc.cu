#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cuda_runtime.h>
#include "timer.h"

// Part-B Q2 (given kernel; you implement the launch scenarios):
// vector add on the GPU with EXPLICIT host<->device copies (cudaMalloc +
// cudaMemcpy). Host and device memory are NOT shared here -- that's what
// Q3 (cudaMallocManaged) changes.
//
// One kernel definition serves all three launch scenarios. `offset` is the
// base element index for a launch: the global index a thread works on is
// offset + blockIdx.x*blockDim.x + threadIdx.x. You decide the offset each
// launch needs so that, together, the launches of a scenario cover all n
// elements exactly once. The `n` bound guards the final partial block, since
// N is not always a multiple of 256. This kernel is given; do not change it.
__global__ void addKernel(long n, int offset, float *z, const float *x, const float *y) {
    long i = (long)offset + blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) z[i] = x[i] + y[i];
}

// runScenario (implemented): covers all n elements with addKernel, split
// across launches according to `scenario`:
//   scenario 1: n launches of <<<1, 1>>>; launch i uses offset i, so each
//               launch adds exactly one element.
//   scenario 2: floor(n/256) launches of <<<1, 256>>> with offsets 0, 256,
//               512, ...; then one <<<1, n % 256>>> launch for the remainder
//               (skipped when n is a multiple of 256).
//   scenario 3: one launch of <<<ceil(n/256), 256>>> with offset 0; the
//               kernel's i < n guard handles the final partial block.
// A single GpuTimer wraps ALL launches of a scenario (plus a final
// cudaDeviceSynchronize), so scenario 1's per-launch overhead is included.
// The host->device copies happen in main() before this, outside the timer.
static float runScenario(int scenario, long n, float *dz, const float *dx, const float *dy)
{
    GpuTimer timer;
    timer.start();
    if (scenario == 1) {
        for (long i = 0; i < n; ++i) addKernel<<<1, 1>>>(n, (int)i, dz, dx, dy);
    } else if (scenario == 2) {
        long full = n / 256;
        for (long b = 0; b < full; ++b) addKernel<<<1, 256>>>(n, (int)(b * 256), dz, dx, dy);
        long rem = n - full * 256;
        if (rem > 0) addKernel<<<1, (int)rem>>>(n, (int)(full * 256), dz, dx, dy);
    } else {
        addKernel<<<(unsigned)((n + 255) / 256), 256>>>(n, 0, dz, dx, dy);
    }
    cudaDeviceSynchronize();
    timer.stop();
    return timer.elapsed_ms();
}

int main(int argc, char **argv)
{
    // Optional CLI args override the K (millions of elements) list, e.g.
    // `./q2_malloc 1` runs only K=1 million -- grade_local.py uses this
    // for a fast correctness/build smoke test. Run with no args to
    // reproduce the full sweep for your report.
    std::vector<int> Ks;
    if (argc > 1) {
        for (int i = 1; i < argc; ++i) Ks.push_back(atoi(argv[i]));
    } else {
        Ks = {1, 5, 10, 50, 100};
    }
    for (size_t kidx = 0; kidx < Ks.size(); ++kidx) {
        int K = Ks[kidx];
        long n = (long)K * 1000000L;
        size_t bytes = (size_t)n * sizeof(float);

        float *hx = (float *)malloc(bytes);
        float *hy = (float *)malloc(bytes);
        float *hz = (float *)malloc(bytes);
        for (long i = 0; i < n; ++i) { hx[i] = 1.0f; hy[i] = 2.0f; }

        float *dx, *dy, *dz;
        cudaMalloc(&dx, bytes);
        cudaMalloc(&dy, bytes);
        cudaMalloc(&dz, bytes);

        for (int scenario = 1; scenario <= 3; ++scenario) {
            // Scenario 1 issues one kernel launch per element, so at large K
            // it would launch tens of millions of kernels and take far too
            // long. Cap it at K <= 10 million; that range already shows the
            // per-launch-overhead blowup. Scenarios 2 and 3 run every K.
            if (scenario == 1 && K > 10) continue;

            cudaMemcpy(dx, hx, bytes, cudaMemcpyHostToDevice);
            cudaMemcpy(dy, hy, bytes, cudaMemcpyHostToDevice);

            float ms = runScenario(scenario, n, dz, dx, dy);

            cudaMemcpy(hz, dz, bytes, cudaMemcpyDeviceToHost);
            double checksum = 0.0;
            for (long i = 0; i < n; ++i) checksum += hz[i];
            bool correct = (checksum == 3.0 * (double)n);

            printf("K=%d scenario=%d time_ms=%.3f checksum=%.1f %s\n",
                   K, scenario, ms, checksum, correct ? "PASSED" : "FAILED");
            printf("RESULT,program=q2_malloc,scenario=%d,K=%d,n=%ld,time_ms=%.3f,checksum=%.1f,correct=%d\n",
                   scenario, K, n, ms, checksum, correct ? 1 : 0);
        }

        free(hx); free(hy); free(hz);
        cudaFree(dx); cudaFree(dy); cudaFree(dz);
    }
    return 0;
}
